package com.example.apphidepro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Gold = Color(0xFFD4AF37)
private val Dark = Color(0xFF101010)
private val Panel = Color(0xFF1D1D1D)
private val Muted = Color(0xFFB7B7B7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppHideProApp() }
    }
}

@Composable
fun AppHideProApp() {
    var unlocked by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("افتح الخزنة باستخدام قفل جهازك") }
    val context = LocalContext.current
    val activity = context as ComponentActivity

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            background = Dark,
            surface = Panel,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        if (unlocked) {
            VaultHome(onLock = { unlocked = false })
        } else {
            LockScreen(
                message = message,
                onUnlock = {
                    val authenticators =
                        BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    val manager = BiometricManager.from(context)
                    when (manager.canAuthenticate(authenticators)) {
                        BiometricManager.BIOMETRIC_SUCCESS -> {
                            val prompt = BiometricPrompt(
                                activity,
                                ContextCompat.getMainExecutor(context),
                                object : BiometricPrompt.AuthenticationCallback() {
                                    override fun onAuthenticationSucceeded(
                                        result: BiometricPrompt.AuthenticationResult
                                    ) {
                                        unlocked = true
                                        message = "تم فتح الخزنة"
                                    }
                                    override fun onAuthenticationError(
                                        errorCode: Int, errString: CharSequence
                                    ) {
                                        message = errString.toString()
                                    }
                                    override fun onAuthenticationFailed() {
                                        message = "لم يتم التحقق. حاول مرة أخرى."
                                    }
                                }
                            )
                            val info = BiometricPrompt.PromptInfo.Builder()
                                .setTitle("APP HIDE PRO")
                                .setSubtitle("تحقق من هويتك لفتح الخزنة")
                                .setAllowedAuthenticators(authenticators)
                                .build()
                            prompt.authenticate(info)
                        }
                        else -> message =
                            "فعّل بصمة أو قفل الشاشة من إعدادات الهاتف أولاً."
                    }
                }
            )
        }
    }
}

@Composable
private fun LockScreen(message: String, onUnlock: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(Dark).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Security, null, tint = Gold, modifier = Modifier.size(76.dp))
        Spacer(Modifier.height(18.dp))
        Text("APP HIDE PRO", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("خزنتك الخاصة", color = Muted, fontSize = 16.sp)
        Spacer(Modifier.height(34.dp))
        Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.Fingerprint, null, tint = Gold, modifier = Modifier.size(54.dp))
                Spacer(Modifier.height(12.dp))
                Text("منطقة آمنة", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(message, color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(22.dp))
                Button(
                    onClick = onUnlock,
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Lock, null)
                    Spacer(Modifier.width(8.dp))
                    Text("فتح الخزنة")
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("خصوصيتك أولويتنا", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun VaultHome(onLock: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(Dark).padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("مرحباً بك", color = Muted, fontSize = 14.sp)
                Text("خزنتك الخاصة", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = onLock) {
                Icon(Icons.Default.Lock, contentDescription = "قفل الخزنة", tint = Gold)
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("أقسام الخزنة", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(14.dp))
        VaultTile(Icons.Default.Image, "الصور", "مكان آمن لحفظ الصور")
        VaultTile(Icons.Default.VideoLibrary, "الفيديوهات", "حفظ مقاطع الفيديو")
        VaultTile(Icons.Default.Folder, "الملفات", "المستندات والملفات الخاصة")
        VaultTile(Icons.Default.Security, "حماية التطبيقات", "إعدادات الحماية وإدارة الخصوصية")
        VaultTile(Icons.Default.Settings, "الإعدادات", "البصمة والقفل والخصوصية")
        Spacer(Modifier.weight(1f))
        Text(
            "نسخة تجريبية 0.1 • لا توجد إعلانات",
            color = Muted,
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun VaultTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Surface(
        color = Panel,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
        }
    }
}
